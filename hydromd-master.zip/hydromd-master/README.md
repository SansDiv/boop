## Information

<div align="center">
<a href="https://github.com/AhmadAkbarID/hydromd/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/AhmadAkbarID/hydromd?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/network/members"><img title="Forks" src="https://img.shields.io/github/forks/AhmadAkbarID/hydromd?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/AhmadAkbarID/hydromd?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/issues"><img title="Issues" src="https://img.shields.io/github/issues/AhmadAkbarID/hydromd?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/issues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/AhmadAkbarID/hydromd?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/pulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/AhmadAkbarID/hydromd?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/AhmadAkbarID/hydromd/pulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/AhmadAkbarID/hydromd?label=PullRequest&color=red&style=flat-square"></a>
</div>

---

## Contributing

I really appreciate the contributions you all have made, therefore I'm displaying them above.

<a href="https://github.com/IbraDecode/socketon/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=AhmadAkbarID/hydromd" alt="contributors" />
</a>

---

This script is created by [Ahmad](https://github.com/AhmadAkbarID) using Node.js and the [Socketon](https://npmjs.com/package/socketon) library. The script is currently in the development phase (BETA), so there may still be some errors that can be ignored. If errors persist even after debugging, please contact the owner for assistance. ~ By Ahmad

#### Join Group
[![Grup WhatsApp](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/FvSBEz1UezQ4G7Xwfrr9sF) 

---
#### Deploy to Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/AhmadAkbarID/hydro)

#### Heroku Buildpack
| Build Pack | LINK |
|--------|--------|
| **NODEJS** | heroku/nodejs |
| **FFMPEG** | [here](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **WEBP** | [here](https://github.com/clhuang/heroku-buildpack-webp-binaries.git) |
| **IMAGEMAGICK** | [here](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |

---
## For Windows/VPS/RDP User
* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/AhmadAkbarID/hydro
cd hydro
npm install
npm update
```
---
## For Panel Pterodactyl User
```step
download sc hydro 
ke panelmu dan ke files
upload sc hydro dan extract
ke isi file dan centang semua
pilih move dan ketik "../"
start panel dengan node 22
```

[ RECOMMENDED INSTALL ON VPS ]
```bash
gitclone https://github.com/AhmadAkbarID/hydro
cd hydro
npm install
npm start
```

---

## Run
```bash
node index.js
```
---

### Features
| Menu     | Bot | Group | Search | Download | Tools | Ai | Game | Fun | Owner |
| -------- | --- | ----- | ------ | -------- | ----- | -- | ---- | --- | ----- |
| Work     |  ✅  |   ✅   |    ✅    |     ✅     |   ✅   | ✅ |   ✅   |  ✅  |    ✅    |
